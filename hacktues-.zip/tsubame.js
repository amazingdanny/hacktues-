let KM = "108 031 958 KM";
let MI = "67 127 946 MI";
let KMs = "90 922 000 KM";
let MIs = "56 496 311 MI";
let swich = 1;
document.getElementById("KM").onclick = function(){
    document.getElementById("P").innerHTML = KM;
}
document.getElementById("MI").onclick = function(){
    document.getElementById("P").innerHTML = MI;
}
document.getElementById("KMs").onclick = function(){
    document.getElementById("P1").innerHTML = KMs;
}
document.getElementById("MIs").onclick = function(){
    document.getElementById("P1").innerHTML = MIs;
}
document.getElementsById ("picturebutton1").onclick = function(){
    swich++;
    if(swich == 4)
    swich = 1;
    if(swich%3 == 2)
    document.getElementsByClassName("firstPicture").innerHTML.src = "venus_1.jpg";
}